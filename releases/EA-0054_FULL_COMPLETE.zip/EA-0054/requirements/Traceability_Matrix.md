| Requirement | Component | Test | Evidence |
|---|---|---|---|
| EA-0054-FR-001 | AQELYN component 1 | Test suite | Evidence record |
| EA-0054-FR-002 | AQELYN component 2 | Test suite | Evidence record |
| EA-0054-FR-003 | AQELYN component 3 | Test suite | Evidence record |
| EA-0054-FR-004 | AQELYN component 4 | Test suite | Evidence record |
| EA-0054-FR-005 | AQELYN component 5 | Test suite | Evidence record |
| EA-0054-FR-006 | AQELYN component 6 | Test suite | Evidence record |
| EA-0054-FR-007 | AQELYN component 7 | Test suite | Evidence record |
| EA-0054-FR-008 | AQELYN component 8 | Test suite | Evidence record |
| EA-0054-FR-009 | AQELYN component 9 | Test suite | Evidence record |
| EA-0054-FR-010 | AQELYN component 10 | Test suite | Evidence record |
| EA-0054-FR-011 | AQELYN component 11 | Test suite | Evidence record |
| EA-0054-FR-012 | AQELYN component 12 | Test suite | Evidence record |
